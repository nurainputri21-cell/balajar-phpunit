<?php declare(strict_types=1);

use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\TestCase;

final class KonversiSuhuTest extends TestCase
{
    #[DataProvider('celsiusKeFahrenheitProvider')]
    public function testMengonversiCelsiusKeFahrenheit(float $celsius, float $expected): void
    {
        // Arrange: siapkan objek yang diuji
        $konversi = new KonversiSuhu();

        // Act: jalankan konversi celsius ke fahrenheit
        $hasil = $konversi->celsiusKeFahrenheit($celsius);

        // Assert: verifikasi hasil menggunakan delta toleransi floating point
        $this->assertEqualsWithDelta($expected, $hasil, 0.001);
    }

    public static function celsiusKeFahrenheitProvider(): array
    {
        return [
            'titik beku'   => [0.0, 32.0],
            'titik didih'  => [100.0, 212.0],
            'suhu negatif' => [-40.0, -40.0],
            'suhu tubuh'   => [36.6, 97.88],
        ];
    }

    #[DataProvider('celsiusKeKelvinProvider')]
    public function testMengonversiCelsiusKeKelvin(float $celsius, float $expected): void
    {
        // Arrange: siapkan objek yang diuji
        $konversi = new KonversiSuhu();

        // Act: jalankan konversi celsius ke kelvin
        $hasil = $konversi->celsiusKeKelvin($celsius);

        // Assert: verifikasi hasil menggunakan delta toleransi floating point
        $this->assertEqualsWithDelta($expected, $hasil, 0.001);
    }

    public static function celsiusKeKelvinProvider(): array
    {
        return [
            'titik beku'   => [0.0, 273.15],
            'titik didih'  => [100.0, 373.15],
            'suhu negatif' => [-40.0, 233.15],
            'suhu tubuh'   => [36.6, 309.75],
        ];
    }
}
